package com.rs.game.minigames;

import com.rs.game.player.controlers.Controler;

public class PuroPuro extends Controler {

	@Override
	public void start() {
		
	}

}
