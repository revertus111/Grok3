package com.rs.game.player.actions;

import com.rs.game.*;
import com.rs.game.item.Item;
import com.rs.game.player.Player;
import com.rs.game.player.Skills;
import com.rs.utils.Utils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.FileReader;
import java.util.*;

public class CombatSpellJsonLoader {

    private static final Map<Integer, CastResult> spellData = new HashMap<>();
    private static final Map<Player, Boolean> staffWarningShown = new HashMap<>();

    public static class ProjectileData {
        public int gfxId, startHeight, endHeight, speed, delay, curve, angle;

        public ProjectileData(int gfxId, int startHeight, int endHeight, int speed, int delay, int curve, int angle) {
            this.gfxId = gfxId;
            this.startHeight = startHeight;
            this.endHeight = endHeight;
            this.speed = speed;
            this.delay = delay;
            this.curve = curve;
            this.angle = angle;
        }
    }

    public static class RuneCost {
        public int id, amount;

        public RuneCost(int id, int amount) {
            this.id = id;
            this.amount = amount;
        }
    }

    public static class CastResult {
        public int id, hitGfx, animationId, damage, delay, requiredStaffId, levelRequired;
        public double xp;
        public String customFormula;
        public int spellbookId;
        public List<String> elements;
        public List<String> effects;
        public List<RuneCost> runes;
        public List<ProjectileData> projectiles;

        public CastResult(int id, int hitGfx, int animationId, int damage, int delay, double xp,
                          int requiredStaffId, int levelRequired, String customFormula, int spellbookId,
                          List<String> elements, List<String> effects, List<RuneCost> runes, List<ProjectileData> projectiles) {
            this.id = id;
            this.hitGfx = hitGfx;
            this.animationId = animationId;
            this.damage = damage;
            this.delay = delay;
            this.xp = xp;
            this.requiredStaffId = requiredStaffId;
            this.levelRequired = levelRequired;
            this.customFormula = customFormula;
            this.spellbookId = spellbookId;
            this.elements = elements;
            this.effects = effects;
            this.runes = runes;
            this.projectiles = projectiles;
        }
    }

    public static void init() {
        spellData.clear();
        try {
            JSONArray array = (JSONArray) new JSONParser().parse(new FileReader("data/json/combat_spells.json"));
            for (Object o : array) {
                JSONObject obj = (JSONObject) o;

                int id = ((Long) obj.get("id")).intValue();
                int hitGfx = ((Long) obj.get("endGfx")).intValue();
                int animationId = ((Long) obj.get("animationId")).intValue();
                int damage = ((Long) obj.get("maxHit")).intValue();
                int delay = ((Long) obj.getOrDefault("delay", 0L)).intValue();
                double xp = ((Number) obj.getOrDefault("xp", 0.0)).doubleValue();
                int requiredStaffId = ((Long) obj.getOrDefault("requiredStaffId", -1L)).intValue();
                int levelRequired = ((Long) obj.getOrDefault("levelRequired", 1L)).intValue();
                int spellbookId = ((Long) obj.getOrDefault("spellbookId", 192L)).intValue();
                String customFormula = (String) obj.getOrDefault("customFormula", "");

                List<RuneCost> runes = new ArrayList<>();
                JSONArray runeArray = (JSONArray) obj.get("runes");
                if (runeArray != null) {
                    for (Object r : runeArray) {
                        JSONObject rObj = (JSONObject) r;
                        runes.add(new RuneCost(((Long) rObj.get("id")).intValue(), ((Long) rObj.get("amount")).intValue()));
                    }
                }

                List<ProjectileData> projectiles = new ArrayList<>();
                JSONArray projArray = (JSONArray) obj.get("projectiles");
                if (projArray != null) {
                    for (Object p : projArray) {
                        JSONObject pObj = (JSONObject) p;
                        projectiles.add(new ProjectileData(
                            ((Long) pObj.get("gfxId")).intValue(),
                            ((Long) pObj.get("startHeight")).intValue(),
                            ((Long) pObj.get("endHeight")).intValue(),
                            ((Long) pObj.get("speed")).intValue(),
                            ((Long) pObj.get("delay")).intValue(),
                            ((Long) pObj.get("curve")).intValue(),
                            ((Long) pObj.get("angle")).intValue()
                        ));
                    }
                }

                List<String> elements = new ArrayList<>();
                JSONArray elementsArray = (JSONArray) obj.get("elements");
                if (elementsArray != null)
                    for (Object el : elementsArray)
                        elements.add((String) el);

                List<String> effects = new ArrayList<>();
                JSONArray effectsArray = (JSONArray) obj.get("effects");
                if (effectsArray != null)
                    for (Object ef : effectsArray)
                        effects.add((String) ef);

                spellData.put(id, new CastResult(id, hitGfx, animationId, damage, delay, xp,
                    requiredStaffId, levelRequired, customFormula, spellbookId, elements, effects, runes, projectiles));
            }
        } catch (Exception e) {
            System.err.println("Failed to load combat spells: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static CastResult castSpell(Player player, Entity target, int spellId) {
        CastResult spell = spellData.get(spellId);
        if (spell == null) return null;

        // Staff requirement
        if (spell.requiredStaffId != -1 && !player.getEquipment().containsOneItem(spell.requiredStaffId)) {
            if (!Boolean.TRUE.equals(staffWarningShown.get(player))) {
                player.getPackets().sendGameMessage("You need the correct staff to cast this spell.");
                staffWarningShown.put(player, true);
            }
            return null;
        }

        // Reset warning if they have correct staff
        staffWarningShown.put(player, false);
        return spell;
    }
}
