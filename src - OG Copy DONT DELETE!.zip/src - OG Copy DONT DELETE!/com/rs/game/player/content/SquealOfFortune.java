package com.rs.game.player.content;

public class SquealOfFortune {

	public static int TAB_INTERFACE_ID = 0;
	
	private static int[] COMMON_REWARDS = {}; 
	
	private static int[] UNCOMMON_REWARDS = {};
	
	private static int[] RARE_REWARDS = {};
	
	private static int[] EXTREME_RARE_REWARDS = {};
}